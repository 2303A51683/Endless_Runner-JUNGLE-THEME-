# Jungle theme changes

The editor builder now creates a jungle explorer, tropical vegetation, ancient stone trail, mossy ruins, temple gate, waterfalls, forest fog and jungle-colored UI. Gameplay systems from the supplied project are retained.
