# JUNGLE RUNNER — Unity 6 Theme Conversion

This project converts the uploaded Fairytale Flight endless runner into a jungle-temple endless runner.

## Editor version
Configured for Unity **6.6 (6000.6.8f1)**. Open with Unity Hub using the JungleRunner folder.

## Build the game
1. Extract the ZIP.
2. In Unity Hub choose Add > Add project from disk and select the `JungleRunner` folder.
3. Wait for Unity to import and compile.
4. If TextMeshPro asks for Essential Resources, use Window > TextMeshPro > Import TMP Essential Resources.
5. In the Unity menu choose **Jungle Runner > Build Everything**.
6. Wait for the builder to generate assets, prefabs, `Assets/Scenes/MainMenu.unity` and `Assets/Scenes/Game.unity`.
7. The MainMenu scene opens automatically. Press Play and select Start Game.

## Jungle theme changes
- New explorer adventurer character with hat, backpack, bedroll, boots and procedural arm/leg running animation.
- Ancient weathered stone path with moss seams and stone curbs.
- Dense tropical jungle trees and layered canopy.
- Broken temple pillars, carved ruins and hanging vines.
- Distant jungle cliffs, ancient temple gate and waterfall ribbons.
- Tropical forest lighting, green atmospheric fog and firefly particles.
- Forest-green menus and HUD, gold coins and emerald-green gems.
- Original endless runner controls, obstacles, coin/gem collection, score, pause, retry, audio and difficulty progression retained.

## Controls
- A / Left Arrow: move left
- D / Right Arrow: move right
- Space / Up Arrow: jump
- Escape: pause/resume

## Notes
The world and character are procedural Unity primitive meshes and materials. The original audio clips and gameplay scripts are retained. This is an editable Unity source project, not a prebuilt executable. The builder uses TextMeshPro and Unity UI; import TMP Essential Resources if prompted.
